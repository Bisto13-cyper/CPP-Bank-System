#include "Bank.hpp"
#include "Users/Customer.hpp"
#include "Users/Employee.hpp"
#include "Users/Admin.hpp"
#include "Accounts/Account.hpp"


using UserInfo=std::unordered_map<std::string , std::unordered_map <std::string , std::string>>;

Bank::Bank(std::string BN,double M,std::string B_P):Bank_Name(BN),Money(M),Bank_Password(B_P) {}
Bank::~Bank(){
Customers.clear();
Employees.clear();
Admins.clear();

}

std::string Bank::getName(){return Bank_Name;}

void Bank::addAdmin(bool HighAccess,std::string N,std::string G,std::string P,std::string J,std::string R,long long NI,double S)
{
if(!HighAccess)
throw AccessRequired();

auto Adm=std::make_unique <Admin>(N,G,P,J,R,NI,S);

Adm->Accesble(true);

Admins[Adm->getId(P)]=std::move(Adm);

}


void Bank:: addCustomer(bool Access , std::string Name , std::string Gamil ,std::string Type , std::string UserPas , long long National , std::string AccountPas , double Balance , double Onther)
    {
if(!Access)
throw AccessRequired();


auto Cus=std::make_unique <Customer> (Name,Gamil,UserPas,National);

if(Bisto::strings::Upper(Type)=="SAVING_ACCOUNT")
Cus->makeSA(AccountPas,Balance,Onther);


else if(Bisto::strings::Upper(Type)=="CHECKING_ACCOUNT")
Cus->makeCA(AccountPas,Balance,Onther);

else
throw FailedSignUp();

Customers[Cus->getId(UserPas)]=std::move(Cus);


}


void Bank :: addEmployee(bool HighAccess,bool isAccess,std::string N,std::string G,std::string P,std::string J,std::string R,long long NI,double S)
{
if(!HighAccess)
throw AccessRequired();

auto Emp=std::make_unique <Employee>(N,G,P,J,R,NI,S);

if(isAccess)
Emp->Accesble(isAccess);

Employees[Emp->getId(P)]=std::move(Emp);

}

void Bank::delAdmin(bool HighAccess , int id , long long Natiol_Number){

if (!HighAccess)
throw AccessRequired();

auto it = Admins.find(id); 

if (it == Admins.end())
throw UserNotFound(); 

std::unordered_map <std::string  , std::string > info;
Customers[id]->getInfo(info);

if(info["National_Number"] != std::to_string(Natiol_Number))
throw FailedSignUp();

Customers.erase(id);


}

std::string Bank :: delCustomer(bool Acces , int id , long long Natiol_Number , std::string reason){
if (!Acces)
throw AccessRequired();

auto it = Customers.find(id); 
if (it == Customers.end())
throw UserNotFound(); 

std::unordered_map <std::string  , std::string > info;
Customers[id]->getInfo(info);

if(info["National_Number"] != std::to_string(Natiol_Number))
throw FailedSignUp();

Customers.erase(id);

return reason;

}

void Bank::delEmployee(bool HighAccess, int employeeId, long long National_Number) {
    if (!HighAccess)
        throw AccessRequired();

    auto it = Employees.find(employeeId);
    if (it == Employees.end()) 
    throw UserNotFound();

std::unordered_map <std::string  , std::string > info;


it->second->getInfo(info);

if(info["National_Number"] != std::to_string(National_Number))
throw FailedSignUp();

    Employees.erase(it);
}


Customer* Bank::getCustomer(int customerId) {
    auto it = Customers.find(customerId);
    if (it != Customers.end()) {
        return it->second.get();
    }
    throw UserNotFound();
    return nullptr; 
}

Employee* Bank::getEmployee(int employeeId) {
    auto it = Employees.find(employeeId);
    if (it != Employees.end()) {
        return it->second.get();
    }
    throw UserNotFound();
    return nullptr; 
}

Admin* Bank:: getAdmin(int Id){ 
auto it = Admins.find(Id);

    if (it != Admins.end()) {
        return it->second.get();
    }
    throw UserNotFound();
    return nullptr; 

}

UserInfo Bank:: getCustomers(std::string BankPas){
if (BankPas != Bank_Password)
throw FailedSignUp();

UserInfo Cus;

for(auto& it:Customers){
std::unordered_map  <std::string , std::string > data;
it.second->getInfo(data);

Cus[it.second->getName()] = data;
}
return Cus;


}

UserInfo Bank:: getEmployees(std::string BankPas){
if (BankPas != Bank_Password)
throw FailedSignUp();

UserInfo Emp;

for(auto& it:Employees){
std::unordered_map  <std::string , std::string > data;
it.second->getInfo(data);

Emp[it.second->getName()] = data;
}
return Emp;
}

UserInfo Bank:: getAdmins(std::string BankPas){ //when admin
    if (BankPas != Bank_Password)
throw FailedSignUp();

UserInfo Adm;

for(auto& it:Admins){
std::unordered_map  <std::string , std::string > data;
it.second->getInfo(data);

Adm[it.second->getName()] = data;
}
return Adm;


}

void Bank:: addMoney(double Add){Money+=Add;}

void Bank:: earseMoney(double Reomve){Money-=Reomve;}

double Bank:: getMoney(std::string BP) {
    if (BP != Bank_Password)
    throw FailedSignUp();
    
    return Money;}

bool Bank:: transfer(Account& From, Account& To ,double Money ){
    try{
From.withdraw(Money, From.PaswithhighAcces(this));
}

catch(InvalidAmountException E){
return false;
} 

catch(InsufficientFundsException E){
    return false;
}

To.deposit(Money);
return true;

}

