
#include <iostream>
#include "Bank.hpp"
#include "Users/Customer.hpp"
#include "Users/Employee.hpp"

#include "Accounts/Account.hpp"
#include "Accounts/SavingAccount.hpp"
#include "Accounts/CheckingAccount.hpp"
#include "BankExcepsion.hpp"

//Here is new version

int main() {
    const std::string BankPas = "BankMasterPas1!";
    Bank bank("Bisto Bank", 1000000.0, BankPas);

    std::cout << "== Opening customer accounts ==\n";
    bank.addCustomer(true, "Ahmed Ali", "ahmed@mail.com", "SAVING_ACCOUNT",
                      "UserPass1!", 29901011234567, "AccPass1!", 1000.0, -1);
    bank.addCustomer(true, "Mona Adel", "mona@mail.com", "CHECKING_ACCOUNT",
                      "UserPass2!", 29802021234567, "AccPass2!", 500.0, 200.0);

    std::cout << "\n== Customers on file ==\n";
    int ahmedId = -1;
    for (auto& [name, info] : bank.getCustomers(BankPas)) {
        std::cout << name << ":\n";
        for (auto& [k, v] : info) std::cout << "  " << k << " = " << v << "\n";
        if (name == "Ahmed Ali") ahmedId = std::stoi(info.at("Id"));
    }

    std::cout << "\n== Hiring an employee, who opens a customer for us ==\n";
    Employee teller("Sara Youssef", "sara@bank.com", "Passw0rd!", "Teller", "Junior",
                     30001011234567, 4500.0);
    std::cout << teller.addCustomer(&bank, "Youssef Adel", "youssef@mail.com",
                                     "SAVING_ACCOUNT", "UserPass3!", 29701011234567,
                                     "AccPass3!", 2000.0, -1) << "\n";

    bank.addEmployee(true, true, "Sara Youssef", "sara@bank.com", "Passw0rd!",
                      "Teller", "Junior", 30001011234567, 4500.0);
    std::cout << "\n== Employees on file ==\n";
    for (auto& [name, info] : bank.getEmployees(BankPas)) {
        std::cout << name << ":\n";
        for (auto& [k, v] : info) std::cout << "  " << k << " = " << v << "\n";
    }

    std::cout << "\n== Deposits, withdrawals, transfers on standalone accounts ==\n";
    Saving_Account savings("SavePas1!", 12345678, 1000.0, 500.0);
    Checking_Account checking("CheckPas1!", 87654321, 300.0, 100.0);

    savings.deposit(250.0);
    std::cout << "Savings balance after deposit: " << savings.CheckBalance("SavePas1!") << "\n";

    bool ok = bank.transfer(savings, checking, 400.0);
    std::cout << "Transfer 400 savings->checking success? " << (ok ? "yes" : "no") << "\n";
    std::cout << "Savings balance:  " << savings.CheckBalance("SavePas1!") << "\n";
    std::cout << "Checking balance: " << checking.CheckBalance("CheckPas1!") << "\n";

    std::cout << "\n== Exception handling demo ==\n";
    try {
        savings.withdraw(999999.0, "SavePas1!"); // way more than balance + limit
    } catch (const BankException& e) {
        std::cout << "Caught expected error: " << e.what() << "\n";
    }

    std::cout << "\n== Closing a customer account ==\n";
    if (ahmedId != -1) {
        std::string reason = bank.delCustomer(true, ahmedId, 29901011234567, "Customer requested closure");
        std::cout << "Closed Ahmed's record. Reason logged: " << reason << "\n";
    }

    std::cout << "\nDone.\n";
    return 0;
}
