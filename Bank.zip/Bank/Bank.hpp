#pragma once

#include <unordered_map>
#include <memory>
#include "helper/bisto.h"

class Customer;
class Employee;
class Admin;
class Account;

class Bank{
private:
std::unordered_map <int  , std::unique_ptr<Customer>> Customers;
std::unordered_map <int  , std::unique_ptr<Employee>> Employees;
std::unordered_map <int  , std::unique_ptr<Admin>> Admins;

std::string Bank_Password;
std::string Bank_Name;
double Money;

int Num_Of_Users;
int Num_Of_Accounts;


using UserInfo=std::unordered_map<std::string , std::unordered_map <std::string , std::string>>;
public:
Bank(std::string BN,double M,std::string B_P);

/*Bank(
std::string BN , double M ,
std::unordered_map <int  , std::unique_ptr<Customer>> Customers,
std::unordered_map <int  , std::unique_ptr<Employee>> Employees,
std::unordered_map <int  , std::unique_ptr<Admin>> Admins
):Bank_Name(BN),Money(M),Customers(Customers),Employees(Employees),Admins(Admins)
{}*/
std::string getName();

void addAdmin(bool HighAccess,std::string Name,std::string Gamil,std::string Password,std::string Jop,std::string Rank,long long National,double Salary);

void addCustomer(bool Access , std::string Name , std::string Gamil ,std::string Type , std::string UserPas , long long National , std::string AccountPas , double Balance , double Onther);

void addEmployee(bool HighAccess,bool isAcces,std::string Name,std::string Gamil,std::string Password,std::string Jop,std::string Rank,long long National,double Salary);

void delAdmin(bool HighAccess , int id , long long Natiol_Number);

std::string delCustomer(bool Access , int id , long long Natiol_Number , std::string reason);

void delEmployee(bool HighAccess , int Id , long long Natiol_Number);

Admin* getAdmin(int Id);

Customer* getCustomer(int Id);

Employee* getEmployee(int Id);

UserInfo getCustomers(std::string BankPas);

UserInfo getEmployees(std::string BankPas);

UserInfo getAdmins(std::string BankPas);

bool transfer(Account& From , Account& To , double Money );

void addMoney(double Add);

void earseMoney(double Reomve);

double getMoney(std::string BankPas);

virtual ~Bank();
};