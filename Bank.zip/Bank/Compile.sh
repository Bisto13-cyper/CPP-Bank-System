all:
 g++ main.cpp Bank.cpp Bank.hpp BankExcepsion.hpp  Users/*.cpp Accounts/*.cpp helper/*.cpp -o BankSystem
 ./BankSystem