#include "Customer.hpp"
#include "../Accounts/Account.hpp"
#include "../Accounts/SavingAccount.hpp"
#include "../Accounts/CheckingAccount.hpp"

Customer::Customer(std::string N,std::string G,long NI):User(N,G,NI){}

Customer::Customer(std::string N,std::string G,std::string P,long long NI):User(N,G,P,NI){}

bool Customer:: login(std::string Pas , int Id , bool Trust){
if(!Trust)
throw FaildAccess();

if(Pas!=Password)
throw InvalidPasException();

if(Id!=U_Id)
return false;

return true;
}

void Customer:: makeSA(std::string Pas , double Ba , double L){
std::unique_ptr<Saving_Account> newSA;

if(L==-1)
newSA=std::make_unique<Saving_Account>(Pas,National_Number, Ba);
else
newSA=std::make_unique<Saving_Account>(Pas,National_Number, Ba,L);

Accounts[newSA->getid()]=std::move(newSA);

}

void Customer:: makeCA(std::string Pas , double Ba , double OV){
std::unique_ptr <Checking_Account> newCA;
if(Ba==-1)
newCA=std::make_unique<Checking_Account>(Pas,National_Number);
else if(OV==-1)
newCA=std::make_unique<Checking_Account>(Pas,National_Number,Ba);
else
newCA=std::make_unique<Checking_Account>(Pas,National_Number,Ba,OV);


Accounts[newCA->getid()]=std::move(newCA);

}

void Customer:: delAc(int del , bool sure , Account* trans , std::string AcPas , std::string UPas){
if(!sure) return;

if(UPas!=Password || !Accounts[del]->isrightpas(AcPas)) 
throw InvalidPasException();

if(Accounts[del]->CheckBalance(AcPas)!=0)
{
Accounts[del]->withdraw(Accounts[del]->CheckBalance(AcPas),AcPas);
}

if(Accounts[del]->CheckBalance(AcPas)>0)
throw OutstandingBalance();

Accounts.erase(del);

}

std::unordered_map<std::string , std::string> Customer:: getACinfo(int id , std::string Pas){
std::unordered_map<std::string , std::string> info;

Accounts[id]->getinfo(info);

return info;
}

void Customer:: getInfo(std::unordered_map<std::string,std::string>& info){
User::getInfo(info);
info["Accounts_Number"]=std::to_string(Accounts.size());
for(auto& pair:Accounts){
info["Type:" + std::to_string(pair.first)]=pair.second->gettype();

}
}

Account* Customer::getaccount (int id){
    auto it = Accounts.find(id);
    if(it != Accounts.end())
    return Accounts[id].get();

    else
    return nullptr; 
}

Customer::~Customer (){
    User::~User();
    Accounts.clear();
}


