#include "Employee.hpp"
#include "../Bank.hpp"
#include "Customer.hpp"
#include "../BankExcepsion.hpp"
#include "../Accounts/Account.hpp"

void Employee:: getInfo(std::unordered_map<std::string,std::string>& Info )
{
User::getInfo(Info);
Info["IsHighAccess"] = Access?"Yes":"No" ;
Info["Jop"] = Jop;
Info["Salary"] = std::to_string( Salary);
Info["Rank"] = Rank;
}


double Employee:: getSalary(){return Salary;}

std::string Employee:: getJop() {return Jop;}

std::string Employee:: getRank(){return Rank;}

std::string Employee:: addCustomer
(Bank* BANK , std::string Name , std::string Gamil , std::string AccountType , std::string UserPas ,long long National_Number , std::string AccPas , double StartBalance , double LimitOrODL)
{
try{
BANK->addCustomer(true , Name , Gamil , AccountType , UserPas , National_Number , AccPas ,StartBalance , LimitOrODL );
}

catch (FailedSignUp){
    return "The Type Of Account Is wrong type\n";
}

return "Customer Added!"; 
}

void Employee::addAc(Bank& bank, int userid , std::string type , std::string AcPas , double FirstBalance , double Other){ 
auto mycus=bank.getCustomer(userid);

type=Bisto::strings::Upper(type);

if(type=="SAVING_ACCOUNT")
mycus->makeSA(AcPas , FirstBalance , Other);


else if (type == "CHECKING_ACCOUNT")
mycus->makeCA(AcPas , FirstBalance , Other);

else
throw FailedSignUp();
}


bool Employee::delAc(Bank& bank, int userid , int Acid , int transid , int Actransid , std::string Accpas , std::string UPas){
auto mycus=bank.getCustomer(userid);
auto mycus2=bank.getCustomer(transid);

auto tranAc=mycus2->getaccount(Actransid);

if (tranAc == nullptr)
throw UserNotFound();


try{
mycus->delAc(Acid , true , tranAc , Accpas , UPas);
}

catch (BankException){
    return false;
}

return true;
 }



std::unordered_map <std::string , std::string > Employee::getdata(Bank& bank,int CusId){ 
if (!Access)
throw AccessRequired();

auto it=bank.getCustomer(CusId);
std::unordered_map <std::string , std::string > data ;
it->getInfo(data);

return data;

}
std::unordered_map <std::string , std::string >  Employee::checkAcc(Bank& bank , int CusId , int Accinfo)
{ 
if (!Access)
throw AccessRequired();

auto it=bank.getCustomer(CusId);

auto Acc=it->getaccount(Accinfo);

std::unordered_map <std::string , std::string > data ;


Acc->getinfo(data);

return data;
}

