#pragma once
#include<unordered_set>
#include "../helper/bisto.h"
#include "../BankExcepsion.hpp"
#include <unordered_map>


//Customer,,employee,,Admin
class User{
private:
Bisto::randoms ID;
static std::unordered_set<int> IDS;

protected:
std::string Password;
std::string Name; 
std::string Gamil; 
long long National_Number;
int U_Id;

public:
User(std::string N,std::string G,long long NI):Name(N),Gamil(G),National_Number(NI),Password("0000"){U_Id=ID.randomInt(0,1000000);}

User(std::string N,std::string G,std::string P,long long NI):Name(N),Gamil(G),National_Number(NI),Password(P){U_Id=ID.randomInt(0,1000000);}

int getId(std::string Pas){
    if(Pas!=Password) 
    throw InvalidPasException();
return U_Id;
}

void  resetpas(std::string OldPas,const std::string& NewPas);

void resetpas(long long Nat,int I,const std::string& NewPas);

std::string getName();

virtual void getInfo(std::unordered_map<std::string,std::string>& Info ); 

virtual ~User();

};



