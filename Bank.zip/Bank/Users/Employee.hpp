#pragma once
#include "User.hpp"

class Bank; 

class Employee:public User{
protected:
bool Access;
double Salary;
std::string Jop;
std::string Rank;


public:

Employee(std::string N,std::string G,std::string J,long long NI,double S):User(N,G,NI),Jop(J),Salary(S){}

Employee(std::string N,std::string G,std::string P,std::string J,long long NI,double S):User(N,G,P,NI),Jop(J),Salary(S) {}

Employee(std::string N,std::string G,std::string P,std::string J,std::string R,long long NI,double S):User(N,G,P,NI),Jop(J),Salary(S),Rank(R) {}

void Accesble(bool A){Access=A;}

void getInfo(std::unordered_map<std::string,std::string>& Info ); 

double getSalary();

std::string getJop();

std::string getRank();

std::string addCustomer(Bank* BANK, std::string Name, std::string Gamil, std::string AccountType,
                         std::string UserPas, long long National_Number, std::string AccPas,
                         double StartBalance, double LimitOrODL);

void addAc(Bank& bank, int userid , std::string type , std::string AcPas , double FirstBalance , double Other);

bool delAc(Bank& bank, int userid , int Acid , int transid , int Actransid , std::string Accpas , std::string UPas);

std::unordered_map <std::string , std::string > getdata(Bank& bank,int CusId);

std::unordered_map <std::string , std::string >  checkAcc(Bank& bank , int CusId , int Accinfo);
};