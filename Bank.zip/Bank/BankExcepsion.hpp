#pragma once

#include <stdexcept>
#include <string>

class BankException : public std::runtime_error {
public:
    explicit BankException(const std::string& message) 
        : std::runtime_error(message) {}
};

class InvalidPasException : public BankException {
public:
    InvalidPasException() : BankException("Security Error: Invalid Account ID provided!") {}
};

class InsufficientFundsException : public BankException {
public:
    InsufficientFundsException() : BankException("Transaction Error: Insufficient balance in the account!") {}
};

class WeakPasswordException : public BankException {
public:
    WeakPasswordException() : BankException("Security Error: Password must be at least 6 characters long!") {}
};

class InvalidAmountException : public BankException {
public:
    InvalidAmountException() : BankException("Transaction Error: Amount must be greater than zero!") {}
};

class ExceededLimitException : public BankException {
public:
    ExceededLimitException() : BankException("Transaction Error: Withdrawal amount exceeds the allowed account limit!") {}
};

class FaildAccess : public BankException {
public:
    FaildAccess() : BankException("This User isn't acceble ! Trust Error") {}
};

class OutstandingBalance : public BankException {
public:
    OutstandingBalance() : BankException("User must return moeny to bank before any action!") {}
};

class FailedSignUp : public BankException {
public:
    FailedSignUp() : BankException("Error When sign up ! check your param or internet") {}
};

class AccessRequired : public BankException {
public:
    AccessRequired() : BankException("Failed ! Accessible") {}
};

class UserNotFound : public BankException {
public:
    UserNotFound() : BankException("Failed ! The User you search isn't here ") {}
};

