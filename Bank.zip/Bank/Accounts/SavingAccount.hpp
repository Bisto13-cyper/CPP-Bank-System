#pragma once
#include <string>
#include <unordered_map>


#include "Account.hpp"

class Saving_Account:public Account{
private:
static double Current_Interest_Rate;
double Interest_Rate;
double Limit_Rate;
double Limits;

public:
Saving_Account(std::string Pas,long long NaNu,double Ba):Account(Pas,NaNu,Ba),Limits(0){Interest_Rate=Current_Interest_Rate;Calclimits();}

Saving_Account(std::string Pas,long long NaNu,double Ba,double L):Account(Pas,NaNu,Ba),Limit_Rate(L),Limits(0){Interest_Rate=Current_Interest_Rate;}

double MapplyInterest();

double YapplyInterest();

double Calclimits();

double resetInterest();

double withdraw(double,std::string);

double getinterest(std::string);

double getlimit(std::string);

double getcurrentlimit(std::string);

std::string gettype();

void monthlyreset(bool isInterestReset);

void yearlyreset(bool isInterestReset);

void displayAccountInfo(std::string);

void getinfo(std::unordered_map <std::string , std::string >& info );

~Saving_Account(){}



};







