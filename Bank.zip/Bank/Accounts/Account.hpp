#pragma once 
#include<string>
#include<unordered_set>
#include<unordered_map>
#include "../helper/bisto.h"

class Bank;

class Account{
private:
Bisto::randoms ID;
static std::unordered_set<int> IDS;

protected:
std::string Password;
long long National_Number;
double Balance;
int id;

public:
Account(std::string Pas,long long NaNu):Password(Pas),National_Number(NaNu),Balance(0){id=genrateuniqe_id();}

Account(std::string Pas,long long NaNu,double Ba):Password(Pas),National_Number(NaNu),Balance(Ba){id=genrateuniqe_id();}

bool isrightpas(std::string);

int genrateuniqe_id();

int getid(){return id;}

void resetpas(std::string,const std::string&);

void resetpas(long long , int ,const std::string&);

void deposit(double ); 

virtual double withdraw(double,std::string)=0; 

double CheckBalance(std::string);

virtual void displayAccountInfo(std::string)=0;

virtual std::string gettype()=0;

virtual void getinfo(std::unordered_map <std::string , std::string >& info );

std::string PaswithhighAcces(Bank* BANK ){
    return Password;
}

virtual ~Account();

};






