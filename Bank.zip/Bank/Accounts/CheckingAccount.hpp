#pragma once
#include <string>
#include <unordered_map>
#include "Account.hpp"

class Checking_Account:public Account{
private:
static double transFee;
double Over_draft_limit;
bool iscooled;

public:
Checking_Account(std::string Pas,long long NaNu):Account(Pas,NaNu,10),iscooled(false){}

Checking_Account(std::string Pas,long long NaNu,double Ba):Account(Pas,NaNu,Ba),iscooled(false){}

Checking_Account(std::string Pas,long long NaNu,double Ba,double OV):Account(Pas,NaNu,Ba),Over_draft_limit(OV),iscooled(false){}

void clooAc();

void setOV(double OV);

double getOV();

double withdraw(double,std::string);

void displayAccountInfo(std::string);

std::string gettype();

void getinfo(std::unordered_map <std::string , std::string >& info );

};



